﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectLimb : MonoBehaviour
{
    private Camera cam;
    private GameObject[] goArray = new GameObject[2];
    // Start is called before the first frame update
    void Start()
    {
        cam = GetComponent<Camera>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            RaycastHit hit;
            Ray ray = cam.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out hit, Mathf.Infinity))
            {
                Transform objectHit = hit.transform;
                print(objectHit.name);
                if (goArray[1] != null)
                {
                    goArray[0] = objectHit.gameObject;
                    goArray[0].GetComponentInParent<MoveLimb>().enabled = true;
                    goArray[1].GetComponentInParent<Rigidbody2D>().velocity = new Vector2(0,0);
                    goArray[1].GetComponentInParent<MoveLimb>().enabled = false;
                    goArray[1] = goArray[0];
                }
                else
                {
                    goArray[0] = objectHit.gameObject;
                    goArray[0].GetComponentInParent<MoveLimb>().enabled = true;
                }
            }
        }
              
    }
}
