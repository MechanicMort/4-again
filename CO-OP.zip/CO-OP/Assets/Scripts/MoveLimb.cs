﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveLimb : MonoBehaviour
{
    private float x;
    private float y;
    [SerializeField]
    private float moveSpeed;
    private Vector2 move;
    private Rigidbody2D rb;
    public GameObject goCentre;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        x = Input.GetAxis("Horizontal");
        y = Input.GetAxis("Vertical");
        move = new Vector2(x * moveSpeed * Time.deltaTime, y*moveSpeed * Time.deltaTime);
        rb.AddForce(move,ForceMode2D.Impulse);
        transform.LookAt(goCentre.transform.position);
        if (Input.GetKey(KeyCode.Space))
        {
            rb.velocity = new Vector2(0,0);
            rb.angularVelocity = 0;
        }
    }
}
