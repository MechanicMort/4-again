﻿// Cristian Pop - https://boxophobic.com/

using UnityEngine;

namespace Boxophobic
{
    public class BLayersEnumAttribute : PropertyAttribute
    {
    }
}

