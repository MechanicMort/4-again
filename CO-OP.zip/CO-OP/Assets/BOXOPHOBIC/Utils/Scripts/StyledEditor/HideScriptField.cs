﻿using System;

namespace Boxophobic.StyledGUI
{
    [AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = false)]
    public sealed class HideScriptField : Attribute
    {

    }
}